import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class BookService {

  books$: Subject<string[]> = new Subject();
  booksArr: string[] = [];
  constructor() { }

  addBook(book: string) {
    // debugger
    this.booksArr.push(book)
    this.books$.next(this.booksArr)
  }
  getList(): Observable<string[]> {
    return this.books$.asObservable()
  }
}
