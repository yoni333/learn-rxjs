import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {

  book:string ;
  constructor(private bookService:BookService) { }

  ngOnInit() {
  }
  add(){
    this.bookService.addBook(this.book)
  }

}
