import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-books-shop',
  templateUrl: './books-shop.component.html',
  styleUrls: ['./books-shop.component.css']
})
export class BooksShopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
